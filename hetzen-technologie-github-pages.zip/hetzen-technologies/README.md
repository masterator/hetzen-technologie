# Hetzen Technologies website

Premium Next.js 15 + TypeScript + Tailwind CSS + Framer Motion + Lucide Icons site, configured as a static export for GitHub Pages.

Live at: **https://masterator.github.io/hetzen-technologie/**

## Deploying

1. Push this project to the `main` branch of `github.com/masterator/hetzen-technologie`.
2. Open the GitHub repository.
3. Go to **Settings**.
4. Go to **Pages**.
5. Under "Build and deployment", set **Source** to **GitHub Actions**.
6. Wait for the "Deploy to GitHub Pages" Actions workflow to finish (Actions tab).
7. Open https://masterator.github.io/hetzen-technologie/

Every future push to `main` re-runs the workflow and redeploys automatically — no manual build step needed.

## Local development

```
npm install
npm run dev
```

## Local production preview

`next start` doesn't work once `output: 'export'` is set (there's no server to start — this is normal for a static export). To preview the actual static build locally instead:

```
npm run build
npm start
```

`npm start` now runs `serve` against the exported `out/` folder, matching how GitHub Pages will actually serve it.

## Before launch — things to replace

- **WhatsApp number**: open `lib/config.ts` and replace `YOUR_WHATSAPP_NUMBER` with the real number in international format, digits only (e.g. `27821234567`). Every WhatsApp button on the site reads from this one place.
- **Contact form backend**: the enquiry form is fully built but has nothing to send to yet (GitHub Pages is static-only). See the comment above `handleContactSubmit` in `components/Site.tsx` for two straightforward ways to connect it (a hosted form service like Formspree/Web3Forms, or a small serverless function).
- **Legal pages**: `/privacy-policy` and `/terms-and-conditions` currently hold clearly-labelled placeholder copy — replace with final legal text before launch.
- **Portfolio**: the portfolio section is explicitly labelled "concept / demonstration" work. Swap in real project results once available.

## Notes on this setup

- The site is a single page (`/`) with in-page anchor navigation (`#services`, `#pricing`, etc.), plus two standalone routes (`/privacy-policy`, `/terms-and-conditions`) and a custom `/404`.
- `public/.nojekyll` is required — without it, GitHub Pages runs the deployed files through Jekyll, which silently strips the `_next/` folder and breaks all styling and scripts.
- `robots.txt` and `sitemap.xml` are generated at build time, scoped to this project's own path. Because this is a GitHub Pages *project* site (not a custom domain), they live at `/hetzen-technologie/robots.txt` rather than the domain root — search engines that check the domain root automatically won't see them, but you can still submit the sitemap URL directly in Google Search Console / Bing Webmaster Tools. This resolves itself automatically if the site ever moves to a custom domain.
- Favicon, home-screen icon, and the social share image were generated from your uploaded logo.
