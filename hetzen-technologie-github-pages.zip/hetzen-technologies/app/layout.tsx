import './globals.css';
import type { Metadata, Viewport } from 'next';
import { SITE_URL } from '../lib/config';

const title = 'Hetzen Technologies | Websites, Software, Automation & Digital Solutions South Africa';
const description = 'Hetzen Technologies helps South African businesses grow through professional websites, custom software, automation, branding and digital solutions.';
const ogImageUrl = `${SITE_URL}opengraph-image.png`;

export const metadata: Metadata = {
  metadataBase: new URL(SITE_URL),
  title,
  description,
  applicationName: 'Hetzen Technologies',
  keywords: ['Hetzen Technologies', 'web development South Africa', 'custom software South Africa', 'business automation', 'branding', 'digital solutions Gauteng'],
  authors: [{ name: 'Hetzen Technologies' }],
  alternates: {
    canonical: SITE_URL,
  },
  openGraph: {
    title,
    description,
    url: SITE_URL,
    siteName: 'Hetzen Technologies',
    images: [{ url: ogImageUrl, width: 1200, height: 630, alt: 'Hetzen Technologies — Technology. Digital Solutions. Business Growth.' }],
    locale: 'en_ZA',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title,
    description,
    images: [ogImageUrl],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
    },
  },
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#0a0a0a',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
