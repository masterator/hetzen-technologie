import Link from 'next/link';

export default function NotFound() {
  return (
    <main className="grid min-h-screen place-items-center bg-[#0a0a0a] px-6 text-center text-white">
      <div>
        <Link href="/" className="mx-auto mb-8 grid h-14 w-14 place-items-center rounded-xl border border-[#d4af37]/50 bg-[#d4af37]/10 text-lg font-bold text-[#d4af37]">HT</Link>
        <div className="text-7xl font-bold text-[#d4af37]">404</div>
        <h1 className="mt-4 text-3xl font-bold sm:text-4xl">PAGE NOT FOUND</h1>
        <p className="mx-auto mt-3 max-w-sm text-white/50">The page you&apos;re looking for doesn&apos;t exist or may have moved.</p>
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <Link href="/" className="btn inline-flex items-center gap-2 rounded-full bg-[#d4af37] px-5 py-3 text-sm font-semibold text-black">BACK TO HOME</Link>
          <Link href="/#contact" className="btn inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-5 py-3 text-sm font-semibold hover:border-[#d4af37]/50">CONTACT HETZEN</Link>
        </div>
      </div>
    </main>
  );
}
