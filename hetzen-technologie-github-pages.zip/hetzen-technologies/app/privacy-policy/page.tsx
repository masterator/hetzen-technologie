import Link from 'next/link';

export default function Privacy() {
  return (
    <main className="min-h-screen bg-[#0a0a0a] px-6 py-24 text-white">
      <div className="mx-auto max-w-3xl">
        <Link href="/" className="text-[#d4af37]">← Back to Hetzen Technologies</Link>
        <h1 className="mt-10 text-5xl font-bold">Privacy Policy</h1>
        <p className="mt-6 text-white/60">This page is a production placeholder. Before launch, replace it with the business&apos;s final privacy policy covering information collected through forms, cookies, analytics, communications and applicable South African privacy requirements.</p>
      </div>
    </main>
  );
}
