/**
 * Site-wide configuration.
 *
 * >>> REPLACE BEFORE LAUNCH <<<
 * WHATSAPP_NUMBER is a placeholder. Set it to the real Hetzen Technologies
 * WhatsApp number in international format, digits only — no "+", no spaces,
 * no dashes (South African mobile example: 27821234567).
 * Every WhatsApp button/link on the site reads from this one constant.
 */
export const WHATSAPP_NUMBER = 'YOUR_WHATSAPP_NUMBER';

export const WHATSAPP_LINK = `https://wa.me/${WHATSAPP_NUMBER}`;

// Canonical, deployed URL of the site (GitHub Pages project site).
// Update this if the site ever moves to a custom domain.
export const SITE_URL = 'https://masterator.github.io/hetzen-technologie/';
