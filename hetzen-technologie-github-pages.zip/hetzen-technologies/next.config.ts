import type { NextConfig } from 'next';

// This repo deploys to https://masterator.github.io/hetzen-technologie/
// i.e. a GitHub Pages *project* site served from a subpath, not the domain root.
// basePath/assetPrefix must match the repository name exactly.
const repoName = 'hetzen-technologie';

const nextConfig: NextConfig = {
  output: 'export',
  basePath: `/${repoName}`,
  assetPrefix: `/${repoName}/`,
  images: {
    unoptimized: true,
  },
  trailingSlash: true,
};

export default nextConfig;
